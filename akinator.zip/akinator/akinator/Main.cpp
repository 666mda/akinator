#include "Visual.h"
void main() {
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	Visual temp; 
	temp.start();
}

